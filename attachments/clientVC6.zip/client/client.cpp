// client.cpp : �ܼ� ���� ���α׷��� ���� �������� �����մϴ�.
//

#include "stdafx.h"
#include <winsock2.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <process.h>

#define DEFAULT_COUNT       20000
#define DEFAULT_PORT        15000
#define DEFAULT_BUFFER      2048
#define DEFAULT_MESSAGE     "This is a test of the emergency \
broadcasting system"

char  szServer[128],          // Server to connect to
      szMessage[1024];        // Message to send to sever
int   iPort     = DEFAULT_PORT;  // Port on server to connect to
DWORD dwCount   = DEFAULT_COUNT; // Number of times to send message
BOOL  bSendOnly = FALSE;         // Send data only; don't receive

UINT __stdcall ThreadFunc(PVOID param);

int main(int argc, char **argv)
{
    WSADATA       wsd;
    
                      
    srand((unsigned)time( NULL ));

    // Parse the command line and load Winsock
    //
	strcpy(szServer,argv[1]);
    int ThreadNum=atoi(argv[2]);
    HANDLE *hThread=new HANDLE[ThreadNum];

    if (WSAStartup(MAKEWORD(2,2), &wsd) != 0)
    {
        printf("Failed to load Winsock library!\n");
        return 1;
    }

    strcpy(szMessage, DEFAULT_MESSAGE);
    
	for(int i=0;i<ThreadNum;i++)
	{		 
         hThread[i]=(HANDLE)_beginthreadex(NULL,0,ThreadFunc,0,0,0);
		 Sleep(rand()%5000);
	}

	WaitForMultipleObjects(ThreadNum,hThread,TRUE,INFINITE);
    for(i=0;i<ThreadNum;i++)
	{		 
         CloseHandle(hThread[i]);		
	}
	delete hThread;
    WSACleanup();
    return 0;
}

UINT __stdcall ThreadFunc(PVOID param)
{
	char          szBuffer[DEFAULT_BUFFER];
	struct sockaddr_in server;
    struct hostent    *host = NULL;
	int ret=0;

	//
    // Create the socket, and attempt to connect to the server
    //
    SOCKET sClient = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sClient == INVALID_SOCKET)
    {
        printf("socket() failed: %d\n", WSAGetLastError());
        return 1;
    }
    server.sin_family = AF_INET;
    server.sin_port = htons(DEFAULT_PORT);
    server.sin_addr.s_addr = inet_addr(szServer);
    //
    // If the supplied server address wasn't in the form
    // "aaa.bbb.ccc.ddd" it's a hostname, so try to resolve it
    //
    if (server.sin_addr.s_addr == INADDR_NONE)
    {
        host = gethostbyname(szServer);
        if (host == NULL)
        {
            printf("Unable to resolve server: %s\n", szServer);
            return 1;
        }
        CopyMemory(&server.sin_addr, host->h_addr_list[0],
            host->h_length);
    }
    if (connect(sClient, (struct sockaddr *)&server, 
        sizeof(server)) == SOCKET_ERROR)
    {
        printf("connect() failed: %d\n", WSAGetLastError());
        return 1;
    }
    // Send and receive data 
    //
	printf("Operation Start %d\n",GetCurrentThreadId());
    for(DWORD i = 0; i < dwCount; i++)
    {
        ret = send(sClient, szMessage, strlen(szMessage), 0);
        if (ret == 0)
            break;
        else if (ret == SOCKET_ERROR)
        {
            printf("[%d] send() failed: %d(%d)\n",GetTickCount(), WSAGetLastError(),GetCurrentThreadId());
            break;
        }
        //printf("Send %d bytes\n", ret);
        if (!bSendOnly)
        {
            ret = recv(sClient, szBuffer, DEFAULT_BUFFER, 0);
            if (ret == 0)        // Graceful close
                break;
            else if (ret == SOCKET_ERROR)
            {
                printf("[%d] recv() failed: %d(%d)\n",GetTickCount(), WSAGetLastError(),GetCurrentThreadId());
                break;
            }
            szBuffer[ret] = '\0';
            //printf("RECV [%d bytes]: '%s'\n", ret, szBuffer);
           }
    }
    closesocket(sClient);
	printf("Operation End %d\n",GetCurrentThreadId());
	return 0;
}

